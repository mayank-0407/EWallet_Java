export const ACCOUNT_TYPE = {
    NORMAL: "Normal",
    MERCHANT:"Merchant",    
  };

export const BASE_URL = "http://localhost:8080/";