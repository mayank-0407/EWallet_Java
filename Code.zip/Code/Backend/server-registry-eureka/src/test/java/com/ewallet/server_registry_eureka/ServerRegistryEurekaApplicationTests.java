package com.ewallet.server_registry_eureka;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServerRegistryEurekaApplicationTests {

	@Test
	void contextLoads() {
	}

}
