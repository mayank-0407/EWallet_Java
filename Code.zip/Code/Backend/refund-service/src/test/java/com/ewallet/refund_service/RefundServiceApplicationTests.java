package com.ewallet.refund_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RefundServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
